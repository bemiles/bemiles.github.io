---
title: Uncooled Microbolometer Array Cameras
author: " "
description: 
summary: an undergraduate led effort to design and operate low cost thermal-ir instruments
date: 
cover:
    image: 
    alt: 
    relative: false
editPost:
    URL:
    Text:

---

---

##### Overview

My undergraduate student Ruben Huerta has been testing the response and sensitivity of the Seek Thermal Mosaic Core Camera. He developed control software for the camera and tested its long-term relative stability against a black body source. Niko Cooper has joined the group to create a faster, lower cost, two temperature point calibration source for the camera. 




---